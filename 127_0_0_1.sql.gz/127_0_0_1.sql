-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 14, 2023 at 02:04 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cv`
--
CREATE DATABASE IF NOT EXISTS `cv` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cv`;

-- --------------------------------------------------------

--
-- Table structure for table `cvtable`
--

CREATE TABLE `cvtable` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cnic` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `appliedfor` varchar(100) NOT NULL,
  `interviewdate` date NOT NULL,
  `status` varchar(100) NOT NULL,
  `comment` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cvtable`
--

INSERT INTO `cvtable` (`id`, `name`, `email`, `cnic`, `phone`, `appliedfor`, `interviewdate`, `status`, `comment`) VALUES
(1, 'Ahmad', 'mawais@soft-enterprise.com', '12312-4123124-1', '1231231231', 'Internship', '2023-06-12', 'Hired', 'asdawdasdasd'),
(2, 'Tariq', 'mawais@soft-enterprise.com', '12312-3123123-1', '1231231231', 'Full Time Position (Offsite)', '2023-03-08', 'Hired', 'asdawdasdasd'),
(3, 'Saim', 'mawais@soft-enterprise.com', '123123123', '1231231231', 'Full Time Position (Offsite)', '2023-05-18', 'Hired', 'asdawdasdasd'),
(4, 'Mohsin', 'mawais@soft-enterprise.com', '123123123', '1231231231', 'Creative designer', '2023-05-22', 'Hired', 'asdawdasdasd123124123123'),
(5, 'Abrar', 'mawais@soft-enterprise.com', '123123123', '1231231231', 'Front End Developer', '2023-05-19', 'Hired', 'asdawdasdasd'),
(6, 'Khalid', 'mawais@soft-enterprise.com', '123123123', '1231231231', 'Search Engine Optimization', '2023-06-01', 'Hired', 'asdawdasdasd'),
(7, 'Shan', 'mawais@soft-enterprise.com', '123123123', '1231231231', 'Digital Marketing', '2023-01-13', 'Hired', 'asdawdasdasd54321'),
(13, 'Zahoor', 'zahoor@abc.com', '3241472943867', '03124835698', 'Backend developer', '2023-05-07', 'Hired', 'comments'),
(14, 'New Name', 'abc@123.com', '3212312312312', '03123123123', 'Internship', '2023-07-08', 'Hired', 'asdawdasd'),
(15, 'asdawdasdasd', 'abc@123.com', '3212312312312', '03123123123 ', 'Internship', '2023-07-08', 'Hired', 'asdawdasd'),
(16, 'asdawdasdasd', 'abc@123.com', '3212312312312', '03123123123 ', 'Internship', '2023-07-08', 'Hired', 'asdawdasd'),
(17, 'asdawdasdasd', 'abc@123.com', '3212312312312', '03123123123', 'Internship', '2023-07-08', 'Hired', 'asdawdasd'),
(21, 'sdawdasda', 'shahid@abc.com', '32312-4123123-1', '03126171515', 'Internship', '2023-07-13', 'Hired', 'asdawdasdawwd');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `username`, `email`, `password`, `role`) VALUES
(10, 'Adeel', 'Adeel911', 'AdeelMukhtar786@abc.com', 'abc123', 'Data Entry User'),
(22, 'Ahmad', 'Ahmad2244', 'ahmadhashmi2244@abc.com', 'password', 'HR User'),
(47, 'Admin', 'Admin', 'Admin@abc.com', 'admin123', 'admin'),
(52, 'Farhan', 'farhan786', 'farhanahmad2244@abc.com', '', 'HR User');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cvtable`
--
ALTER TABLE `cvtable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cvtable`
--
ALTER TABLE `cvtable`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
